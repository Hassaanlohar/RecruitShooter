RECRUIT SHOOTER - ANDROID APP PROJECT
=====================================
This folder is an Android Studio / Gradle project that wraps the game in a full-screen, landscape app.
The app contains the game itself. To play multiplayer you still run server.js on a PC (see the other README);
in the app you type the PC's address (e.g. 192.168.1.23 - the server window shows it), then Host or Join with the PIN.

BUILD THE APK - easiest, no software to install (free GitHub account):
 1. Create a new private repository on github.com and upload everything in this folder
    (drag & drop the files/folders into the repo page; keep the .github folder).
 2. Open the repo's "Actions" tab -> "Build APK" -> wait ~3 minutes for the green tick.
    (If it did not start by itself: Actions -> Build APK -> "Run workflow".)
 3. Open the finished run -> "Artifacts" -> download RecruitShooter-apk -> unzip -> app-debug.apk
 4. Send app-debug.apk to your phone, tap it, allow "install unknown apps" when asked.

OR build with Android Studio: File -> Open this folder -> Build -> Build APK(s).

To change the game later: replace app/src/main/assets/index.html with a new Recruit_Shooter.html and rebuild.
